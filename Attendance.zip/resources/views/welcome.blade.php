<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
        <!-- Styles -->
        <style>
            
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
            #target {
  height: 400px;
  width: 700px;
  background-color: #f8f8f8;
  margin: 200px auto;
  overflow:hidden;
  border-radius:5px;
  box-shadow:2px 2px 5px #888;
}
.hover::before {
  content: 'Drop excel file here.';
  width: 100%;
  height: 100%;
  display: block;
  text-align: center;
  line-height: 400px;
  font-size: 24px;
}
#target>table{
  height:250px;
  width:400px;
  border:1px solid #ccc;
  border-radius:3px;
  margin:75px auto;
}
#target>table td{
  text-align:center;
  border-top:1px solid #ccc;
  border-left:1px solid #ccc;
}
#target>table tr:first-child>td{
  border-top:0px solid #ccc;
}
#target>table tr>td:first-child{
  border-left:0px solid #ccc;
}
            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div class="container">
                    <div class="card bg-light mt-3">
                        <div class="card-header">
                            Laravel 7 Import Export Excel to database 
                        </div>
                        <div class="card-body">
                            <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div id="app">
  
                                    <div ref="target" id="target" class="hover">
                                      <table>
                                        <tr v-for="data in tableData">
                                          <td v-for="row in data">{{row}}</td>
                                        </tr>
                                      </table>
                                    </div>
                                  </div>
                                <input type="file" name="file" class="form-control">
                                <br>
                                <button class="btn btn-success">Import User Data</button>
                                <a class="btn btn-warning" href="{{ route('export') }}">Export User Data</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.5.0/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.5/xlsx.min.js"></script>
    </body>
</html>
